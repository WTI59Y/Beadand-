<?php 
	$query = "SELECT * FROM auto ORDER BY marka";
	require_once DATABASE_CONTROLLER;
	$auto = getList($query);
?>
<?php if(count($auto) <= 0) : ?>
		<h1>Nem található autó a rendszerben!</h1>
	<?php else : ?>
		<?php foreach ($auto as $item) : ?>
		<div class="adat">
		<h2>Márkája és típusa : <?=$item['marka'].' '.$item['tipus']?></h2>
        <br>
        <br>
        <p>Végsebessége : <?=$item['vegsebesseg'] == 0 ? '50+ km/h' : ($item['vegsebesseg'] == 1 ? '100+ km/h' : '200+ km/h') ?></p>
        <p>Hengerűrtartalma : <?=$item['hengerurtartalom']?>cc</p>
        <p>Egyéb információk : <?=$item['leiras']?></p>
        </div>
		<br>
		<hr>
        <br>
   		
		<?php endforeach; ?>
<?php endif; ?>