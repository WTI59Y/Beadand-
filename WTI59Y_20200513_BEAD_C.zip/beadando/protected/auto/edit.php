<?php if(!isset($_SESSION['permission']) || $_SESSION['permission'] < 2) : ?>
	<h1>Nincs hozzá elég magas jogosultsági szinted!</h1>
<?php else :
	if(!array_key_exists('a', $_GET) || empty($_GET['a'])) : 
		header('Location: index.php');
	else: 

	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['editAuto'])) {
	$postData = [
		'id' => $_POST['autoId'],
		'marka' => $_POST['marka'],
		'tipus' => $_POST['tipus'],
		'hengerurtartalom' => $_POST['hengerurtartalom'],
		'vegsebesseg' => $_POST['vegsebesseg'],
		'leiras' => $_POST['leiras']
	];
	if($postData['id'] != $_GET['a']) {
		echo "Error during identifying!";
	} else {
		if(empty($postData['marka']) || $postData['vegsebesseg'] < 0 && $postData['vegsebesseg'] > 2|| empty($postData['tipus']) || empty($postData['hengerurtartalom'])|| empty($postData['leiras'])) {
			echo "Hiányzó adatok!";
		} else {
			$query = "UPDATE auto SET marka = :marka, tipus = :tipus, hengerurtartalom = :hengerurtartalom, vegsebesseg= :vegsebesseg, leiras = :leiras WHERE id = :id";
			$params = [
				':marka' => $postData['marka'],
				':tipus' => $postData['tipus'],
				':hengerurtartalom' => $postData['hengerurtartalom'],
				':vegsebesseg' => $postData['vegsebesseg'],
				'leiras' => $_POST['leiras'],
				':id' => $postData['id']
			];
			require_once DATABASE_CONTROLLER;
			if(!executeDML($query, $params)) {
				echo "Hiba a szerkesztés során!";
			} header('Location: ?P=list_auto');
		}
	}
}

	$query = "SELECT * FROM auto WHERE id = :id";
	$params = [':id' => $_GET['a']];
	require_once DATABASE_CONTROLLER;
	$auto = getRecord($query, $params);
	if(empty($auto)) :
		header('Location: index.php');
		else : ?>
			<form method="post">
			<input type="hidden" name="autoId" value="<?=$auto['id'] ?>">
		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="autoMarka">Márka</label>
				<input type="text" class="form-control" id="autoMarka" name="marka" value="<?=$auto['marka']?>">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="autoTipus">Típus</label>
				<input type="text" class="form-control" id="autoTipus" name="tipus" value="<?=$auto['tipus']?>">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
		    	<label for="autoVegsebesseg">Végsebesség</label>
		    	<select class="form-control" id="autoVegsebesseg" name="vegsebesseg">
		      		<option value="0" <?=$auto['vegsebesseg'] == 0 ? 'selected' : '' ?> >50+ km/h</option>
		      		<option value="1" <?=$auto['vegsebesseg'] == 1 ? 'selected' : '' ?> >100+ km/h</option>
		      		<option value="2" <?=$auto['vegsebesseg'] == 2 ? 'selected' : '' ?> >200+ km/h</option>
		    	</select>
		  	</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="autoHengerurtartalom">Hengerűrtartalom</label>
				<input type="text" class="form-control" id="autoHengerurtartalom" name="hengerurtartalom" value="<?=$auto['hengerurtartalom']?>">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="autoLeiras">Leírás</label>
				<input type="text" class="form-control" id="autoLeiras" name="leiras" value="<?=$auto['leiras']?>">
			</div>
		</div>

		<button type="submit" class="btn btn-primary" name="editAuto">Mentés</button>
</form>
		<?php endif;
	endif;
endif;
?>