<?php
if(array_key_exists('a', $_GET) && !empty($_GET['a'])) {
        $query = "SELECT * FROM auto";
        $params = [':id' => $_GET['a']];
        require_once DATABASE_CONTROLLER;
        if(!executeDML($query, $params)) { 
            echo "Hiba a megnyitás közben!";
        }
        $list = getList($query);
    } 
?>

<?php $i = 0; ?>
<?php foreach ($list as $item) : ?>
    <?php $i++; ?>
    <?php if(array_key_exists('a', $_GET) && !empty($_GET['a'])) : ?>

    <?php if($item['id'] == $_GET['a']) : ?> 
        <center>
        <h2>Márkája és típusa : <?=$item['marka'].' '.$item['tipus']?></h2>
        <br>
        <br>
        <p>Végsebessége : <?=$item['vegsebesseg'] == 0 ? '50+ km/h' : ($item['vegsebesseg'] == 1 ? '100+ km/h' : '200+ km/h') ?></p>
        <p>Hengerűrtartalma : <?=$item['hengerurtartalom']?>cc</p>
        <p>Egyéb információk : <?=$item['leiras']?></p>
        </center>
    <?php endif; ?>
    <?php endif; ?>
<?php endforeach; ?>