<?php if(!isset($_SESSION['permission']) || $_SESSION['permission'] < 1) : ?>
	<h1>Nincs hozzá elég magas jogosultsági szinted!</h1>
<?php else : ?>

	<?php
	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['addAuto'])) {
		$postData = [
			'marka' => $_POST['marka'],
			'vegsebesseg' => $_POST['vegsebesseg'],
			'tipus' => $_POST['tipus'],
			'hengerurtartalom' => $_POST['hengerurtartalom'],
			'leiras' => $_POST['leiras']
		];

		if(empty($postData['marka']) || $postData['vegsebesseg'] < 0 && $postData['vegsebesseg'] > 2|| empty($postData['tipus']) || empty($postData['hengerurtartalom']) || empty($postData['leiras'])) {
			echo "Hiányzó adatok!";
		
		} else {
			$query = "INSERT INTO auto (marka, vegsebesseg, tipus, hengerurtartalom, leiras) VALUES (:marka, :vegsebesseg, :tipus, :hengerurtartalom, :leiras)";
			$params = [
				':marka' => $postData['marka'],
				':vegsebesseg' => $postData['vegsebesseg'],
				':tipus' => $postData['tipus'],
				':hengerurtartalom' => $postData['hengerurtartalom'],
				':leiras' =>$postData['leiras']
			];
			require_once DATABASE_CONTROLLER;
			if(!executeDML($query, $params)) {
				echo "Hiba az adatbevitel során!";
			} header('Location: index.php?P=list_auto');
		}
	}
	?>

	<form method="post">
		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="autoMarka">Márka</label>
				<input type="text" class="form-control" id="autoMarka" name="marka">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="autoTipus">Típus</label>
				<input type="text" class="form-control" id="autoTipus" name="tipus">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="autoHengerurtartalom">Hengerűrtartalom</label>
				<input type="text" class="form-control" id="autoHengerurtartalom" name="hengerurtartalom">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
		    	<label for="autoVegsebesseg">Végsebesség</label>
		    	<select class="form-control" id="autoVegsebesseg" name="vegsebesseg">
		      		<option value="0">50+ km/h</option>
		      		<option value="1">100+ km/h</option>
		      		<option value="2">200+ km/h</option>
		    	</select>
		  	</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="autoLeiras">Leírás</label>
				<input type="text" class="form-control" id="autoLeiras" name="leiras">
			</div>
		</div>

		<button type="submit" class="btn btn-primary" name="addAuto">Autó hozzáadása</button>
	</form>
<?php endif; ?>