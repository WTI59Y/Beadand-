<?php if(!isset($_SESSION['permission']) || $_SESSION['permission'] < 1) : ?>
	<h1>Page access is forbidden!</h1>
<?php else : ?>
<?php 
	if(array_key_exists('d', $_GET) && !empty($_GET['d'])) {
		$query = "DELETE FROM auto WHERE id = :id";
		$params = [':id' => $_GET['d']];
		require_once DATABASE_CONTROLLER;
		if(!executeDML($query, $params)) {
			echo "Hiba a törlés közben!";
		}
	}
?>
<?php 
	$query = "SELECT * FROM auto ORDER BY marka";
	require_once DATABASE_CONTROLLER;
	$auto = getList($query);
?>
	<?php if(count($auto) <= 0) : ?>
		<h1>Nincsenek autók a rendszerben!</h1>
	<?php else : ?>
		<table class="table table-striped">
			<thead>
				<tr>
					<th scope="col">#</th>
					<th scope="col">Márka</th>
					<th scope="col">Típus</th>
					<th scope="col">Végsebesség</th>
					<th scope="col">Hengerűrtartalom</th>
					<th scope="col">Leírás</th>
					<th scope="col">Értékelés</th> 
					<th scope="col">Szerkesztés</th>
					<th scope="col">Törlés</th>
				</tr>
			</thead>
			<tbody>
				<?php $i = 0; ?>
				<?php foreach ($auto as $a) : ?>
					<?php $i++; ?>
					<tr>
						<th scope="row"><?=$i ?></th>
						<td><a href="index.php?P=view&a=<?=$a['id'] ?>"><?=$a['marka'] ?></a></td>
						<td><?=$a['tipus'] ?></td>
						<td><?=$a['vegsebesseg'] == 0 ? '50+ km/h' : ($a['vegsebesseg'] == 1 ? '100+ km/h' : '200+ km/h') ?></td>
						<td><?=$a['hengerurtartalom'] ?>cc</td>
						<td><?=$a['leiras'] ?></td>
						<td>
							<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
							<span class="fa fa-star <?=$a['vegsebesseg'] >= 0 ? 'checked' : "" ?>"></span>
							<span class="fa fa-star <?=$a['vegsebesseg'] >= 0 ? 'checked' : "" ?>"></span>
							<span class="fa fa-star <?=$a['vegsebesseg'] >= 0 ? 'checked' : "" ?>"></span>
							<span class="fa fa-star <?=$a['vegsebesseg'] >= 1 ? 'checked' : "" ?>"></span>
							<span class="fa fa-star <?=$a['vegsebesseg'] >= 2 ? 'checked' : "" ?>"></span>
						</td>
						<td><a href="index.php?P=edit_auto&a=<?=$a['id'] ?>">Szerkesztés</a></td>
						<td><a href="?P=list_auto&d=<?=$a['id'] ?>">Törlés</a></td>
					</tr>
				<?php endforeach;?>
			</tbody>
		</table>
	<?php endif; ?>
<?php endif; ?>